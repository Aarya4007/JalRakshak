from flask import (
    Flask, render_template, request,
    redirect, url_for, session
)

from database import create_table, get_connection

from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash

import os
import uuid

app = Flask(__name__)
app.secret_key = "JalRakshak_Hackathon_2026_Secret"
# Upload folder settings
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app.config["UPLOAD_FOLDER"] = os.path.join(
    BASE_DIR, "static", "uploads"
)

app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

# Create database table
create_table()


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


# Home page
@app.route("/")
def home():
    return render_template("index.html")


# Complaint form
@app.route("/report", methods=["GET", "POST"])
def report():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        mobile = request.form.get("mobile", "").strip()
        email = request.form.get("email", "").strip()
        location = request.form.get("location", "").strip()
        leakage_type = request.form.get("leakage_type", "").strip()
        description = request.form.get("description", "").strip()

        # Check required fields
        if not all([
            name, mobile, email, location,
            leakage_type, description
        ]):
            return "Please fill all required fields.", 400

        if not mobile.isdigit() or len(mobile) != 10:
            return "Please enter a valid 10-digit mobile number.", 400

        complaint_id = "JAL" + uuid.uuid4().hex[:8].upper()

        photo = request.files.get("photo")
        photo_name = None

        if photo and photo.filename:

            if not allowed_file(photo.filename):
                return "Only PNG, JPG, JPEG and WEBP images are allowed.", 400

            original_name = secure_filename(photo.filename)

            photo_name = complaint_id + "_" + original_name

            photo_path = os.path.join(
                app.config["UPLOAD_FOLDER"],
                photo_name
            )

            photo.save(photo_path)

        # Save complaint in database
        conn = get_connection()

        conn.execute("""
            INSERT INTO complaints
            (complaint_id, name, mobile, email, location,
             leakage_type, description, photo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            complaint_id,
            name,
            mobile,
            email,
            location,
            leakage_type,
            description,
            photo_name
        ))

        conn.commit()
        conn.close()

        return render_template(
            "success.html",
            complaint_id=complaint_id
        )

    return render_template("report.html")


# Track page (we will develop this next)
@app.route("/track", methods=["GET", "POST"])
def track():

    complaint = None
    message = None

    if request.method == "POST":

        complaint_id = request.form.get(
            "complaint_id", ""
        ).strip().upper()

        conn = get_connection()

        complaint = conn.execute(
            "SELECT * FROM complaints WHERE complaint_id = ?",
            (complaint_id,)
        ).fetchone()

        conn.close()

        if complaint is None:
            message = "Complaint ID not found. Please check your ID."

    return render_template(
        "track.html",
        complaint=complaint,
        message=message
    )

# ==============================
# ADMIN LOGIN
# ==============================

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_connection()

        admin = conn.execute(
            "SELECT * FROM admins WHERE username = ?",
            (username,)
        ).fetchone()

        conn.close()

        if admin and check_password_hash(
            admin["password"], password
        ):
            session["admin"] = username
            return redirect(url_for("admin_dashboard"))

        return render_template(
            "login.html",
            error="Invalid username or password!"
        )

    return render_template("login.html")


# ==============================
# ADMIN DASHBOARD
# ==============================

@app.route("/admin")
def admin_dashboard():

    if "admin" not in session:
        return redirect(url_for("admin_login"))

    conn = get_connection()

    complaints = conn.execute(
        "SELECT * FROM complaints ORDER BY id DESC"
    ).fetchall()

    total = conn.execute(
        "SELECT COUNT(*) FROM complaints"
    ).fetchone()[0]

    pending = conn.execute(
        "SELECT COUNT(*) FROM complaints WHERE status='Pending'"
    ).fetchone()[0]

    progress = conn.execute(
        "SELECT COUNT(*) FROM complaints WHERE status='In Progress'"
    ).fetchone()[0]

    resolved = conn.execute(
        "SELECT COUNT(*) FROM complaints WHERE status='Resolved'"
    ).fetchone()[0]

    conn.close()

    return render_template(
        "admin.html",
        complaints=complaints,
        total=total,
        pending=pending,
        progress=progress,
        resolved=resolved
    )


# ==============================
# UPDATE COMPLAINT STATUS
# ==============================

@app.route("/admin/update/<int:id>", methods=["POST"])
def update_status(id):

    if "admin" not in session:
        return redirect(url_for("admin_login"))

    status = request.form.get("status")

    if status not in ["Pending", "In Progress", "Resolved"]:
        return "Invalid status", 400

    conn = get_connection()

    conn.execute(
        "UPDATE complaints SET status=? WHERE id=?",
        (status, id)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("admin_dashboard"))


# ==============================
# DELETE COMPLAINT
# ==============================

@app.route("/admin/delete/<int:id>", methods=["POST"])
def delete_complaint(id):

    if "admin" not in session:
        return redirect(url_for("admin_login"))

    conn = get_connection()

    conn.execute(
        "DELETE FROM complaints WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("admin_dashboard"))


# ==============================
# ADMIN LOGOUT
# ==============================

@app.route("/admin/logout")
def admin_logout():

    session.pop("admin", None)

    return redirect(url_for("admin_login"))
if __name__ == "__main__":
    app.run(debug=True)